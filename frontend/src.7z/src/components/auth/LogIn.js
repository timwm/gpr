import React from 'react'

const LogIn = () => {
  return (
    <div>LogIn</div>
  )
}

export default LogIn