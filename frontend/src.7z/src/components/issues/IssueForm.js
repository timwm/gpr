import React from 'react'

const IssueForm = () => {
  return (
    <div>IssueForm</div>
  )
}

export default IssueForm