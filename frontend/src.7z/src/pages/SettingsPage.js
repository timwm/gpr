import React from "react";

const SettingsPage = () => {
  return (
    <div className="p-10 bg-blue-100 w-full">
      <h1 className="text-4xl font-bold">Settings</h1>
    </div>
  );
};

export default SettingsPage;
