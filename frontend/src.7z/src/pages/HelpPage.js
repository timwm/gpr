import React from "react";

const HelpPage = () => {
  return (
    <div className="p-10 bg-blue-100 w-full">
      <h1 className="text-4xl font-bold">Help Page</h1>
    </div>
  );
};

export default HelpPage;
